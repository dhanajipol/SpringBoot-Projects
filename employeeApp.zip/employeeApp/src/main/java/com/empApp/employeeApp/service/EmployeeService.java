package com.empApp.employeeApp.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.empApp.employeeApp.entity.Employee;

@Service
public interface EmployeeService {

	public List<Employee> getAllEmployee();

	public Employee getEmployeeById(long empId);

	public Employee addEmployee(Employee employee);

	public Employee updateEmployee(Employee employee);

	public List<Employee> deleteEmployee(long empId);

}
