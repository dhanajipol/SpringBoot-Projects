package com.empApp.employeeApp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.empApp.employeeApp.entity.Employee;
import com.empApp.employeeApp.service.EmployeeService;

//We can Tell to the SpringBoot that this Will be Controller/ Presentation layer for our project By annotating @RestController
@RestController
public class EmployeeController {

	// Injecting Service Class for Auto wiring by @Autowired
	@Autowired
	private EmployeeService employeeService;

	// When client hits the request from browser / PostMan App, This controller
	// method will Provide response to the Client
	// Client Request Format :- http://localhost:8080/employee

	// 8080 port is the default port for SpringBoot Project
	@GetMapping("/employee")
	public List<Employee> getAllEmployee() {

		return this.employeeService.getAllEmployee();
	}

	@GetMapping("/employee/{empId}")
	public Employee getEmployeeById(@PathVariable long empId) {

		return this.employeeService.getEmployeeById(empId);
	}

	@PostMapping("/employee")
	public Employee addEmployee(@RequestBody Employee employee) {
		return this.employeeService.addEmployee(employee);
	}

	@PutMapping("/employee/{empId}")
	public Employee updateEmployee(@RequestBody Employee employee, @PathVariable long empId) {

		return this.employeeService.updateEmployee(employee);
	}

	@DeleteMapping("/employee/{empId}")
	public List<Employee> deleteEmployee(@PathVariable long empId) {
		return this.employeeService.deleteEmployee(empId);
	}

}
