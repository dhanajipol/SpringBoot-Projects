package com.empApp.employeeApp.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.empApp.employeeApp.entity.Employee;

//We can Inform to The SpringBoot That this will be My Service Class by annotating  @Service
@Service
public class EmployeeServiceImpl implements EmployeeService {

	private List<Employee> list;

	EmployeeServiceImpl() {

		// Creating list for adding employee objects to the list with the help of
		// Constructor
		list = new ArrayList<>();
		list.add(new Employee(1, "Gaurav", "50000"));
		list.add(new Employee(2, "Dhanaji", "70000"));
	}

	// This Function Will Return List of All Employee
	@Override
	public List<Employee> getAllEmployee() {

		return this.list;
	}

	// THis Function will Return The only One Employee Whose Id Provided by The
	// Client Through PostMan App.
	@Override
	public Employee getEmployeeById(long empId) {
		Employee e = null;
		for (Employee employee : list) {
			if (employee.getEmpId() == empId) {
				e = employee;
			}
		}
		return e;
	}

	// This Function Will Add The Employee & Added Employee Will be return
	@Override
	public Employee addEmployee(Employee employee) {

		list.add(employee);
		return employee;
	}

	// This Function Update the Existing Employee & return the updated Employee
	@Override
	public Employee updateEmployee(Employee employee) {

		for (Employee emp : list) {
			if (emp.getEmpId() == employee.getEmpId()) {
				emp.setEmpName(employee.getEmpName());
				emp.setEmpSalary(employee.getEmpSalary());
			}
		}
		return employee;
	}

	// This Function Will delete the Employee from The List & return The Deleted
	// Employee
	@Override
	public List<Employee> deleteEmployee(long empId) {

		int count = 0; // Initializing Variable & Assigning to 0
		for (Employee employee : list) {

			if (employee.getEmpId() == empId) {

				list.remove(count);
				break;
			}
			count++; // It will Count from 0 to 1 & Increase accordingly ForEach loops iteration
			// This logic is wrote for find out the index of Employee object which is going
			// to be delete
		}
		return list;
	}

}
