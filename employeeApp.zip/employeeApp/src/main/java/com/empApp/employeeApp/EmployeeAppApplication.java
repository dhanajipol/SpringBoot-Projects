package com.empApp.employeeApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeAppApplication.class, args);
		System.out.println(
				"This is Sample for SpringBoot Project/nTHis Project consist of Simmple REST API Web Service Without Connecting Database");
		System.out.println("Use PostMan For Making Request ");
	}

}
